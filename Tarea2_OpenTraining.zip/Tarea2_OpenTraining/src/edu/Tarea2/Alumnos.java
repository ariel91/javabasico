/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.Tarea2;

/**
 *
 * @author Ariel Chitay
 */
public class Alumnos extends SeresVivos {
    
    public Alumnos(String Nom, int ed) {
        super(Nom, ed);
    }
    
    public void Carrera(){
        System.out.println("Soy Estudiante de Ingenieria");
    }
    
}
