/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.Tarea2;

/**
 *
 * @author Ariel Chitay
 */
public class Loros extends SeresVivos{
    
    public Loros(String Nom, int ed) {
        super(Nom, ed);
    }
    
}
